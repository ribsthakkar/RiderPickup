#!/usr/bin/env python

try:
    from pySDPEN import SDPEN
    __all__ = ['SDPEN']
except:
    __all__ = []
#end
