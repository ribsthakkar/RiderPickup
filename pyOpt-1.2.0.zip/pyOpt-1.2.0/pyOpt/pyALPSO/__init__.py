#!/usr/bin/env python

try:
    from pyALPSO import ALPSO
    __all__ = ['ALPSO']
except:
    __all__ = []
#end
