#!/usr/bin/env python

try:
    from pyFILTERSD import FILTERSD
    __all__ = ['FILTERSD']
except:
    __all__ = []
#end
