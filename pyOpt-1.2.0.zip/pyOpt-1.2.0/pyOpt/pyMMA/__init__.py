#!/usr/bin/env python

try:
    from pyMMA import MMA
    __all__ = ['MMA']
except:
    __all__ = []
#end
