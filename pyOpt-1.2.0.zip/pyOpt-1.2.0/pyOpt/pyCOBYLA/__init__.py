#!/usr/bin/env python

try:
    from pyCOBYLA import COBYLA
    __all__ = ['COBYLA']
except:
    __all__ = []
#end
