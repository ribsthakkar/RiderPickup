#!/usr/bin/env python

try:
    from pyNLPQLP import NLPQLP
    __all__ = ['NLPQLP']
except:
    __all__ = []
#end
