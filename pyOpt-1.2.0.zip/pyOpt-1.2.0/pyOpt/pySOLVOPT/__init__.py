#!/usr/bin/env python

try:
    from pySOLVOPT import SOLVOPT
    __all__ = ['SOLVOPT']
except:
    __all__ = []
#end
